package com.salesmanager.shop.init.data;

import com.salesmanager.core.business.exception.ServiceException;

public interface InitData {
	
	public void initInitialData() throws ServiceException;

}
