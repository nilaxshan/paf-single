package com.salesmanager.shop.store.model.filter;

public enum QueryFilterType {
	
	BRAND

}
