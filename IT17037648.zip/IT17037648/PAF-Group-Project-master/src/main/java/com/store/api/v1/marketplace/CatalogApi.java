package com.salesmanager.shop.store.api.v1.marketplace;

public class CatalogApi {

}
