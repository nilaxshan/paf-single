package com.salesmanager.shop.model.system;

import com.salesmanager.shop.model.entity.Entity;

public class Optin extends Entity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
