package com.salesmanager.shop.model.system;

public class ReadableOptin extends OptinEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
