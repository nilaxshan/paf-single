package com.salesmanager.shop.model.security;

public class ReadablePermission extends PermissionEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
