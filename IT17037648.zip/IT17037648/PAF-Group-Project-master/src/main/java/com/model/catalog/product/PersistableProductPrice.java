package com.salesmanager.shop.model.catalog.product;

public class PersistableProductPrice extends ProductPriceEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
