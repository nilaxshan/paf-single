package com.salesmanager.shop.model.entity;

public interface ReadableAuditable {
	
	void setReadableAudit(ReadableAudit audit);
	ReadableAudit getReadableAudit();

}
