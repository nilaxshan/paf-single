package com.salesmanager.shop.model.catalog.product.attribute;

import java.io.Serializable;

import com.salesmanager.shop.model.catalog.CatalogEntity;


public class ProductOptionDescription extends CatalogEntity implements
		Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
