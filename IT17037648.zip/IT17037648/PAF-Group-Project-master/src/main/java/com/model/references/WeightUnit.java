package com.salesmanager.shop.model.references;

public enum WeightUnit {
	
	LB,KG,//GR

}
