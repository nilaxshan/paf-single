package com.salesmanager.shop.model.references;

public class ReadableAddress extends Address {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


}
