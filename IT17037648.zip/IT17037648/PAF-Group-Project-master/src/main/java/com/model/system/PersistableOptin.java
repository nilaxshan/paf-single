package com.salesmanager.shop.model.system;

public class PersistableOptin extends OptinEntity {

}
