package com.salesmanager.shop.model.marketplace;

import com.salesmanager.shop.model.entity.Entity;

public class MarketPlaceEntity extends Entity {

}
