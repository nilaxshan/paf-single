package com.salesmanager.shop.model.catalog.manufacturer;

import java.io.Serializable;

import com.salesmanager.shop.model.catalog.CatalogEntity;


public class ManufacturerDescription extends CatalogEntity implements
		Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
