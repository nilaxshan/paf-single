package com.salesmanager.shop.model.catalog.product;

import com.salesmanager.shop.model.catalog.CatalogEntity;

public class ProductDescription extends CatalogEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
