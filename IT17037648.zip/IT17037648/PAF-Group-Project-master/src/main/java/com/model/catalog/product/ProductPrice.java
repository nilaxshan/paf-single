package com.salesmanager.shop.model.catalog.product;

import com.salesmanager.shop.model.entity.Entity;

public class ProductPrice extends Entity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public final static String DEFAULT_PRICE_CODE="base";

}
