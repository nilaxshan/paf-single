package com.salesmanager.shop.model.references;

public enum MeasureUnit {
	
	
	CM,
	IN,
	//METER,
	//FOOT
	;

}
