package com.salesmanager.shop.model.entity;

public class ReadableEntity extends Entity {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

}
