package com.salesmanager.shop.model.shop;

public class PersistableBrand extends MerchantStoreBrand {

}
